# Working with a node

